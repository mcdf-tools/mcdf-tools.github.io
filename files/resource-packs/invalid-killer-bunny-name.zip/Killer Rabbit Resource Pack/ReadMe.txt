This resource pack was made by bluecrab2
Contact:
Discord - @Bluecrab2#1996
Email - bluecrab2mc@gmail.com

This resource pack was made for 1.8 and should work from 1.8 to 1.8.9.
For 15w31a - 17w47b the pack_format number will have to be changed from 1 to 2 in pack.mcmeta
The resource pack can be used to get a nameless killer rabbit upgraded from 14w27a or 14w27b to have any desired name if loaded with the language active. 
From 14w34a to 17w50a any nameless killer rabbit that is loaded would gain the string of the translation of entity.KillerBunny.name permanently and once loaded it will remain that string even after changing languages.
The resource pack can be used to get the killer rabbit to change names to normally impossible strings in survival, including names longer than the anvil limit, 0 length string, or a string that consist only of spaces.
These names can also be distinguished from name tags because the killer rabbit will still have PersistenceRequired set to 0b meaning it can despawn which is not the case when using name tags.

Instructions on How to Use Pack:

1. Unzip Folder
2. Place the "Killer Rabbit Resource Pack" folder in .minecraft\resourcepacks (or other instance if you are using a separate launcher)
3. Open Killer Rabbit Resource Pack\assets\minecraft\lang\rb_WK.lang with a text editor such as Notepad or Wordpad
4. Replace "Rabbit Name Goes Here" after "entity.KillerBunny.name=" with the desired name and save
5. Open Minecraft, in Options > Resource Packs select the "Killer Rabbit Resource Pack"
6. In Options > Languages change to "Rabbitese (Wiki)"
7. Load Nameless Killer Rabbit and Read Name Tag to See Your Chosen Name

Note: To test if the resource pack is working a new killer rabbit can be created with /summon Rabbit ~ ~ ~ {RabbitType:99} and it should also gain the resource pack name